
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'aahmed31',
  applicationName: 'serverless-bookquotes',
  appUid: 'RbF5qPHSJNt3fQY9n9',
  orgUid: '5bbc8730-c772-4d96-a61c-0769f2abf493',
  deploymentUid: '9f90c4e3-f15c-4c39-b986-7b251a8a33c9',
  serviceName: 'serverless-bookquotes',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'production',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-bookquotes-production-typesense-lambda', timeout: 6 };

try {
  const userHandler = require('./lambdas/typesense-lambda-index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}